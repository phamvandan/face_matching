'''
Uses weights and models implementation' from
https://github.com/deepinsight/insightface
'''
from image_infer import  *
import os
import cv2
import argparse
from keras.models import load_model
import face_alignment
from tqdm import tqdm
import sys
sys.path.insert(0, '../FaceBoxes.PyTorch/')
import mytest
import json
from support_function import get_file_name, resize_image, process_image
if __name__ == '__main__':
    # img_heights = [[1000, 1500]]
    # img_heights = [[1000, 1500]]
    img_heights = [[500]]
    ## load model
    ## face model
    face_model = mytest.face_boxes_model()
    face_model.load_face_model()
    ## face alignment model
    fa = Handler('./model/2d106det', 0, ctx_id=-1)

    filenames = get_file_name(face_model.args.folder)
    count = 0
    miss = 0
    total_time = 0
    for i, filename in enumerate(tqdm(filenames)):
        origin_img = cv2.imread(filename)
        for img_height in img_heights:
            start = time.time()
            aligned, error = process_image(origin_img, img_height, face_model=face_model, fa_model=fa, detect_thresh=float(0.8))
            total_time += time.time() - start
            if aligned is not None:
                count = count + 1
                cv2.imwrite(os.path.join(face_model.args.savefolder, filename.split("/")[-1]), aligned)
            else:
                miss = miss + 1
                print(error)
    print("acc:", count/len(filenames))
    print("miss:", miss)
    print("time:", total_time/len(filenames))