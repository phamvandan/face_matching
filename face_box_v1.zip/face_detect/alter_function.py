"""Alter support function"""

import cv2, sys, os, time, imutils, shutil, math
import numpy as np
import datetime
import sys
sys.path.insert(0, '../insightface/src/common')
import face_preprocess

def aligned_face(face_img, box, landmark):
    nimg = face_preprocess.preprocess(face_img, box, landmark, image_size='112,112')
    temp = nimg.copy()
    nimg = cv2.cvtColor(nimg, cv2.COLOR_BGR2RGB)
    aligned = np.transpose(nimg, (2, 0, 1))
    return aligned, temp

# Disable
def blockPrint():
    sys.stdout = open(os.devnull, 'w')


# Restore
def enablePrint():
    sys.stdout = sys.__stdout__


''' rotate image with any angle '''


def rotate(mat, angle):
    if angle == 0:
        return mat
    height, width = mat.shape[:2]
    image_center = (width / 2, height / 2)
    rotation_mat = cv2.getRotationMatrix2D(image_center, angle, 1.)
    abs_cos = abs(rotation_mat[0, 0])
    abs_sin = abs(rotation_mat[0, 1])
    bound_w = int(height * abs_sin + width * abs_cos)
    bound_h = int(height * abs_cos + width * abs_sin)
    rotation_mat[0, 2] += bound_w / 2 - image_center[0]
    rotation_mat[1, 2] += bound_h / 2 - image_center[1]
    rotated_mat = cv2.warpAffine(mat, rotation_mat, (bound_w, bound_h))
    return rotated_mat

'''Get all files name from folder'''


def get_file_name(folder):
    filenames = []
    for path, subdirs, files in os.walk(folder):
        for name in files:
            filename = os.path.join(path, name)
            filenames.append(filename)
    return filenames


'''Resize image with option'''


def resize_image(img, img_height):
    start = time.time()
    temp = img.copy()
    if img_height != -1:
        temp = imutils.resize(temp, height=img_height)
    return temp, time.time() - start

def show_img(img, name="ok"):
    cv2.imshow(name, img)
    cv2.waitKey(0)

def draw_points(face_img, points):
    for point in points:
        a, b = point
        a = int(a)
        b = int(b)
        cv2.circle(face_img, (a, b), 3, (0, 255, 0), -1)
        # face_img = imutils.resize(face_img, height=500)
    show_img(face_img)

def draw_rect(img, detected_face):
    x,y,a,b,_ = detected_face
    x = int(x)
    y = int(y)
    a = int(a)
    b = int(b)
    print("face shape", (int(a-x), int(b-y)))
    cv2.rectangle(img, (x,y), (a,b), (0,255,255),2)
    show_img(img)

import datetime

def save_random(img, name="fail"):
    if not os.path.exists("./" + name):
        os.mkdir("./"+name)
    i = datetime.datetime.now()
    cv2.imwrite(name + "/" + "{}{}{}".format(i.minute, i.second, i.microsecond) + ".jpg",
                img)

def save(img, x1, y1, x2, y2, name="eye"):
    if not os.path.exists("./" + name):
        os.mkdir("./"+name)
    h, w = img.shape[:2]
    x1 = max(x1, 0)
    x2 = min(x2, w)
    y1 = max(y1, 0)
    y2 = min(y2, h)
    # rect = (x1,y1,x2,y2,0)
    # draw_rect(img, rect)
    i = datetime.datetime.now()
    cv2.imwrite(name + "/" + "{}{}{}".format(i.minute, i.second, i.microsecond) + ".jpg",
                img[int(y1):int(y2), int(x1):int(x2)])
