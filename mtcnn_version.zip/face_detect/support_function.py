from alter_function import *

def get_boxes(bboxs, thresh, img=None):
    detected_faces = []
    for bbox in bboxs:
        x, y, a, b, confidence = bbox
        if abs(a-x) < 15 or abs(b-y) < 15 or confidence < thresh:
            continue
        detected_faces.append(bbox)
    if len(detected_faces) == 0:
        return  None
    detected_faces = sorted(detected_faces, key=lambda x: x[4], reverse=True)
    return detected_faces[0]

def normalize_landmark(landmark):
    # LEFT_EYE = [36, 37, 38, 39, 40, 41]
    # RIGHT_EYE = [42, 43, 44, 45, 46, 47]
    # NOSE = [29, 30]
    # LEFT_MOUTH = [48, 49, 59]
    # RIGHT_MOUTH = [53, 54, 55]
    points = np.zeros((5, 2))
    points[0] = landmark[38]
    points[1] = landmark[92]
    points[2] = landmark[86]
    points[3] = landmark[52]
    points[4] = landmark[61]
    return points


def get_shape(detected_face):
    x, y, a, b,_ = detected_face
    return (a-x)*(b-y)


import numpy as np

def process(origin_img, face_img, fa_model, detected_face = None):
    ori_h, ori_w = origin_img.shape[:2]
    h, w = face_img.shape[:2]
    error = "No face"
    if detected_face is not None:
        df = detected_face
        detected_face[0] = detected_face[0]*ori_w/w
        detected_face[1] = detected_face[1]*ori_h/h
        detected_face[2] = detected_face[2]*ori_w/w
        detected_face[3] = detected_face[3]*ori_h/h
        ## if origin image smaller than resized
        if get_shape(df) > get_shape(detected_face):
            origin_img = face_img
            detected_face = df

        landmark = fa_model.get(origin_img, detected_face)[0]
            # if debug:
            #     draw_points(origin_img.copy(), landmark)
        points = normalize_landmark(landmark)
            # if debug:
            #     draw_points(origin_img.copy(), points)
            # rs = predict_eye(landmark, origin_img, eye_model, points, size)
            # if rs:
                # get_eye_mouth(origin_img,landmark, 1)
                # x,y,a,b,_= detected_face 
                # save(origin_img, x,y,a,b, "face")
        nimg, aligned = aligned_face(origin_img, detected_face, points)
                # if debug:
        # show_img(aligned)
        return aligned, error
        # return None, "-1"
    else:
        error = "Below threshold "
    return aligned, error


'''Main processing image'''
def process_image(origin_img, img_heights, face_model, fa_model, detect_thresh):
    aligned = None
    max_img = [None, None, None, 0]
    for img_height in img_heights:
        img, _ = resize_image(origin_img, img_height)
        for i in range(4):
            temp = rotate(img, 90 * i)
            temp_ori = rotate(origin_img, 90 * i)
            face_img_resize = temp.copy()
            face_img_ori = temp_ori.copy()
            temp = np.float32(temp)
            bboxs = face_model.detect_faces(temp, getLandmark=False)
            if bboxs is None:
                continue
            detected_face = get_boxes(bboxs, detect_thresh)
            if detected_face is None:
                continue
            if detected_face[4] > max_img[3]:
                max_img[0] = face_img_ori
                max_img[1] = face_img_resize
                max_img[2] = detected_face
                max_img[3] = detected_face[4]
        if max_img[0] is not None:
            break

    if max_img[0] is None:
        error_type = "can not detect"
        print("can not detect")
        save_random(origin_img)
        return aligned, error_type

    aligned, error_type = process(max_img[0], max_img[1], fa_model,
    detected_face=max_img[2])
    if aligned is not None:
        return aligned, error_type
    print(error_type)
    return aligned, error_type