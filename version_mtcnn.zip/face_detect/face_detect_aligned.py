'''
Uses weights and models implementation' from
https://github.com/deepinsight/insightface
'''
from image_infer import  *
import os
import cv2
import argparse
from keras.models import load_model
import face_alignment
from tqdm import tqdm
import sys
sys.path.insert(0, '../insightface/deploy/')
import face_model_split
import json
from support_function import get_file_name, resize_image, process_image

def add_argumentation(parser):
    parser.add_argument('--folder', '-f', help='image folder')
    parser.add_argument('--savefolder', '-sf', help='image folder')
    parser.add_argument('--thresh', '-th', default=0.9, help='threshold')
    # ArcFace params
    parser.add_argument('--image-size', default='112,112', help='')
    parser.add_argument('--model', help='path to model.',
                        default='../../insightface/models/model-r100-ii/model,0')
    parser.add_argument('--ga-model', default='', help='path to load model.')
    parser.add_argument('--gender_model', default='',
                        help='path to load model.')
    parser.add_argument('--gpu', default=0, type=int, help='gpu id')
    parser.add_argument('--det', default=1, type=int,
                        help='mtcnn: 1 means using R+O, 0 means detect from begining')
    parser.add_argument('--flip', default=0, type=int,
                        help='whether do lr flip aug')
    parser.add_argument('--threshold', default=1.24,
                        type=float, help='ver dist threshold')
    return parser

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Extract features with CNN')
    parser = add_argumentation(parser)
    args = parser.parse_args()
    args.gpu = -1
    args.det = 0
    args.model = ""
    args.thresh = 0.8

    img_heights = [[800]]
    ## load model
    ## face model
    face_model = face_model_split.FaceModel(args)
    ## face alignment model
    fa = Handler('./model/2d106det', 0, ctx_id=-1)

    filenames = get_file_name(face_model.args.folder)
    count = 0
    miss = 0
    total_time = 0
    for i, filename in enumerate(tqdm(filenames)):
        origin_img = cv2.imread(filename)
        for img_height in img_heights:
            start = time.time()
            aligned, error = process_image(origin_img, img_height, face_model=face_model, fa_model=fa, detect_thresh=float(0.8))
            total_time += time.time() - start
            if aligned is not None:
                count = count + 1
                cv2.imwrite(os.path.join(face_model.args.savefolder, filename.split("/")[-1]), aligned)
            else:
                miss = miss + 1
                print(error)
    print("acc:", count/len(filenames))
    print("miss:", miss)
    print("time:", total_time/len(filenames))